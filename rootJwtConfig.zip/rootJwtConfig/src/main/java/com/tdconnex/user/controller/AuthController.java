package com.tdconnex.user.controller;

import com.tdconnex.security.JwtUtil;
import com.tdconnex.user.dto.JwtResponse;
import com.tdconnex.user.dto.LoginRequest;
import com.tdconnex.user.dto.RegisterRequest;
import com.tdconnex.user.entity.User;
import com.tdconnex.user.repo.UserRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/auth")
public class AuthController
{
    private final AuthenticationManager am;
    private final JwtUtil jwt;
    private final UserRepository repo;
    private final PasswordEncoder encoder;

    public AuthController(AuthenticationManager am,
                          JwtUtil jwt,
                          UserRepository repo,
                          PasswordEncoder encoder) {
        this.am = am;
        this.jwt = jwt;
        this.repo = repo;
        this.encoder = encoder;
    }

    @PostMapping("/register")
    public ResponseEntity<?> register(
            @RequestBody RegisterRequest r) {

        if (repo.findByUsername(r.getUsername()).isPresent()) {
            return ResponseEntity
                    .status(HttpStatus.CONFLICT)
                    .body("Username already exists");
        }

        User u = new User();
        u.setUsername(r.getUsername());
        u.setPassword(encoder.encode(r.getPassword()));
        u.setRole("ROLE_USER");

        repo.save(u);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body("User registered successfully");
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(
            @RequestBody LoginRequest r) {

        am.authenticate(
                new UsernamePasswordAuthenticationToken(
                        r.getUsername(), r.getPassword()));

        User u = repo.findByUsername(r.getUsername()).get();
        return ResponseEntity.ok(
                new JwtResponse(
                        jwt.generateToken(
                                u.getUsername(), u.getRole())));
    }
}
